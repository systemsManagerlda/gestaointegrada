import React from 'react'

function PromptCard() {
  return (
    <div>PromptCard</div>
  )
}

export default PromptCard